import React, { useMemo, useState } from 'react';
import { Linking, Pressable, Share, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { usePalette } from '../hooks/useTheme';
import type { LayerKey, QueryResult } from '../types';
import { VerdictCard } from './VerdictCard';
import { ZoneCard } from './ZoneCard';
import { Banner, Card, Divider, GhostButton, InfoRow, SectionTitle } from './ui';
import { Chevron, Collapsible, FadeInUp } from './motion';
import { layerLabel } from '../logic/labels';
import { ENAIRE_DRONES_URL } from '../api/enaire';
import { ELEVATION_SOURCE } from '../api/elevation';
import { buildShareText, enaireViewerUrl } from '../logic/share';
import { space, type } from '../theme';

export function ResultView({
  result,
  place,
  onHeightChange,
  onRefresh,
  refreshing,
}: {
  result: QueryResult;
  place?: string | null;
  onHeightChange?: (h: number) => void;
  onRefresh?: () => void;
  refreshing?: boolean;
}) {
  const p = usePalette();
  const [showOthers, setShowOthers] = useState(false);
  const [showData, setShowData] = useState(false);

  const affecting = result.verdict.affecting;
  const others = result.verdict.notAffecting;
  const expired = result.zones.filter((z) => z.timing === 'CADUCADA');

  const queriedAt = useMemo(
    () =>
      new Date(result.queriedAt).toLocaleString('es-ES', {
        dateStyle: 'medium',
        timeStyle: 'short',
      }),
    [result.queriedAt],
  );

  const share = () => {
    Share.share({ message: buildShareText(result, place) }).catch(() => {});
  };

  return (
    <View style={{ gap: space.lg }}>
      <VerdictCard
        result={result}
        place={place}
        onHeightChange={onHeightChange}
        onRefresh={onRefresh}
        refreshing={refreshing}
      />

      {result.verdict.incomplete ? (
        <Banner tone="warn">
          No ha respondido {result.failedLayers.map((l: LayerKey) => layerLabel[l]).join(', ')}. Esta
          comprobación está incompleta: no la des por buena.
        </Banner>
      ) : null}

      {result.terrainElevation === null ? (
        <Banner tone="warn">
          No se ha podido obtener la elevación del terreno en este punto. Las zonas con límites
          referidos al nivel del mar se muestran como si te afectaran, por prudencia.
        </Banner>
      ) : null}

      <View style={{ flexDirection: 'row', gap: space.sm }}>
        <View style={{ flex: 1 }}>
          <GhostButton label="Compartir" icon="share-outline" onPress={share} />
        </View>
        <View style={{ flex: 1 }}>
          <GhostButton
            label="Ver en ENAIRE"
            icon="open-outline"
            onPress={() =>
              Linking.openURL(enaireViewerUrl(result.coords.lat, result.coords.lon)).catch(() => {})
            }
          />
        </View>
      </View>

      {affecting.length > 0 ? (
        <FadeInUp animationKey={result.queriedAt} delay={80}>
          <View style={{ gap: space.md }}>
            <SectionTitle>
              {affecting.length === 1
                ? 'La zona que te afecta'
                : `Las ${affecting.length} zonas que te afectan`}
            </SectionTitle>
            {affecting.map((z, i) => (
              <ZoneCard key={z.key} zone={z} defaultOpen={affecting.length === 1 && i === 0} />
            ))}
          </View>
        </FadeInUp>
      ) : null}

      {others.length > 0 ? (
        <View style={{ gap: space.md }}>
          <Pressable
            onPress={() => setShowOthers((v) => !v)}
            accessibilityRole="button"
            accessibilityState={{ expanded: showOthers }}
            style={{ flexDirection: 'row', alignItems: 'center', gap: space.sm, minHeight: 36 }}
          >
            <Chevron open={showOthers} color={p.textMuted} size={16} />
            <Text style={[type.overline, { color: p.textMuted, textTransform: 'uppercase', flex: 1 }]}>
              {others.length} {others.length === 1 ? 'zona que no te afecta' : 'zonas que no te afectan'} a
              esta altura
            </Text>
          </Pressable>
          <Collapsible open={showOthers}>
            <View style={{ gap: space.md }}>
              {others.map((z) => (
                <ZoneCard key={z.key} zone={z} dimmed />
              ))}
            </View>
          </Collapsible>
        </View>
      ) : null}

      {result.verdict.advisories.length > 0 ? (
        <View style={{ gap: space.md }}>
          <SectionTitle>Avisos de ENAIRE para toda España</SectionTitle>
          {result.verdict.advisories.map((z) => (
            <ZoneCard key={z.key} zone={z} />
          ))}
        </View>
      ) : null}

      {expired.length > 0 ? (
        <View style={{ gap: space.md }}>
          <SectionTitle>Zonas ya no vigentes</SectionTitle>
          {expired.map((z) => (
            <ZoneCard key={z.key} zone={z} dimmed />
          ))}
        </View>
      ) : null}

      <Card padded={false}>
        <Pressable
          onPress={() => setShowData((v) => !v)}
          accessibilityRole="button"
          accessibilityState={{ expanded: showData }}
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            gap: space.sm,
            padding: space.lg,
            minHeight: 52,
          }}
        >
          <Chevron open={showData} color={p.textMuted} size={16} />
          <Text style={[type.captionStrong, { color: p.textMuted, flex: 1 }]}>
            Datos y fuentes de esta consulta
          </Text>
        </Pressable>
        <Collapsible open={showData}>
          <View style={{ paddingHorizontal: space.lg, paddingBottom: space.lg }}>
            <InfoRow
              label="Coordenadas"
              value={`${result.coords.lat.toFixed(5)}, ${result.coords.lon.toFixed(5)}`}
            />
            <InfoRow
              label="Elevación del terreno"
              value={
                result.terrainElevation === null
                  ? 'No disponible'
                  : `${Math.round(result.terrainElevation)} m sobre el nivel del mar`
              }
            />
            <InfoRow
              label="Tu dron llegaría a"
              value={
                result.terrainElevation === null
                  ? `${result.flightHeightAgl} m sobre el terreno`
                  : `${Math.round(result.terrainElevation + result.flightHeightAgl)} m sobre el nivel del mar`
              }
            />
            <InfoRow
              label="Zonas en el punto"
              value={`${result.zones.filter((z) => !z.advisory).length} (+${result.verdict.advisories.length} aviso general)`}
            />
            <InfoRow label="Consultado" value={queriedAt} />
            <Divider />
            <InfoRow label="Zonas" value="ENAIRE · Zonas Geográficas UAS (ED-318)" />
            <InfoRow label="Elevación" value={ELEVATION_SOURCE} />
          </View>
        </Collapsible>
      </Card>

      <Banner>
        Esta app consulta en directo el servicio oficial de ENAIRE, pero no lo sustituye. Antes de
        volar comprueba también NOTAM y avisos vigentes: la responsabilidad del vuelo siempre es del
        piloto.{' '}
        <Text
          style={{ color: p.accent, textDecorationLine: 'underline' }}
          onPress={() => Linking.openURL(ENAIRE_DRONES_URL).catch(() => {})}
        >
          Abrir ENAIRE Drones
        </Text>
      </Banner>
    </View>
  );
}
