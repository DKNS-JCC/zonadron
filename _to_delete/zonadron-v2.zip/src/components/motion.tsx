import React, { useEffect, useRef, useState } from 'react';
import { Animated, Easing, View, type ViewStyle } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

/**
 * Animaciones hechas con la API `Animated` del propio React Native, sin
 * dependencias extra y sin `LayoutAnimation` (que no es fiable con la nueva
 * arquitectura en Android).
 */

const DURATION = 220;
const EASE = Easing.out(Easing.cubic);

/** Contenido que se despliega y se pliega con altura animada. */
export function Collapsible({
  open,
  children,
}: {
  open: boolean;
  children: React.ReactNode;
}) {
  const [height, setHeight] = useState(0);
  const anim = useRef(new Animated.Value(open ? 1 : 0)).current;
  const firstRun = useRef(true);

  useEffect(() => {
    if (firstRun.current) {
      firstRun.current = false;
      anim.setValue(open ? 1 : 0);
      return;
    }
    Animated.timing(anim, {
      toValue: open ? 1 : 0,
      duration: DURATION,
      easing: EASE,
      useNativeDriver: false,
    }).start();
  }, [open, anim]);

  return (
    <Animated.View
      style={{
        height: anim.interpolate({ inputRange: [0, 1], outputRange: [0, height] }),
        opacity: anim,
        overflow: 'hidden',
      }}
      pointerEvents={open ? 'auto' : 'none'}
    >
      <View onLayout={(e) => setHeight(e.nativeEvent.layout.height)}>{children}</View>
    </Animated.View>
  );
}

/** Entrada suave: sube 12 px y aparece. Para tarjetas de resultado. */
export function FadeInUp({
  children,
  delay = 0,
  distance = 12,
  style,
  /** Cambiar esta clave vuelve a lanzar la animación. */
  animationKey,
}: {
  children: React.ReactNode;
  delay?: number;
  distance?: number;
  style?: ViewStyle;
  animationKey?: string | number;
}) {
  const anim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    anim.setValue(0);
    Animated.timing(anim, {
      toValue: 1,
      duration: 280,
      delay,
      easing: EASE,
      useNativeDriver: true,
    }).start();
  }, [anim, delay, animationKey]);

  return (
    <Animated.View
      style={[
        style,
        {
          opacity: anim,
          transform: [
            { translateY: anim.interpolate({ inputRange: [0, 1], outputRange: [distance, 0] }) },
          ],
        },
      ]}
    >
      {children}
    </Animated.View>
  );
}

/** Flecha que rota en vez de cambiar de icono. */
export function Chevron({
  open,
  color,
  size = 18,
}: {
  open: boolean;
  color: string;
  size?: number;
}) {
  const anim = useRef(new Animated.Value(open ? 1 : 0)).current;

  useEffect(() => {
    Animated.timing(anim, {
      toValue: open ? 1 : 0,
      duration: DURATION,
      easing: EASE,
      useNativeDriver: true,
    }).start();
  }, [open, anim]);

  return (
    <Animated.View
      style={{
        transform: [
          { rotate: anim.interpolate({ inputRange: [0, 1], outputRange: ['0deg', '90deg'] }) },
        ],
      }}
    >
      <Ionicons name="chevron-forward" size={size} color={color} />
    </Animated.View>
  );
}

/** Pulso suave para los esqueletos de carga. */
export function Pulse({ children }: { children: React.ReactNode }) {
  const anim = useRef(new Animated.Value(0.45)).current;

  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(anim, { toValue: 1, duration: 700, easing: Easing.inOut(Easing.ease), useNativeDriver: true }),
        Animated.timing(anim, { toValue: 0.45, duration: 700, easing: Easing.inOut(Easing.ease), useNativeDriver: true }),
      ]),
    );
    loop.start();
    return () => loop.stop();
  }, [anim]);

  return <Animated.View style={{ opacity: anim }}>{children}</Animated.View>;
}
