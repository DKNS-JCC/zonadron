/**
 * Verificación del motor contra el servicio real de ENAIRE.
 *
 * No es un test de interfaz: comprueba que la app dice la verdad. Para cada
 * punto conocido consulta ENAIRE en directo, calcula el veredicto con la misma
 * lógica que usa la app y comprueba que coincide con lo esperado.
 *
 *   npm run test:motor
 */

import { normalizeZone, queryZonesAt } from '../src/api/enaire';
import { getTerrainElevation } from '../src/api/elevation';
import { buildVerdict, evaluateZones } from '../src/logic/verdict';
import { htmlToText } from '../src/logic/html';
import type { RawZoneAttributes, VerdictLevel } from '../src/types';

interface Case {
  nombre: string;
  lat: number;
  lon: number;
  altura: number;
  /** Niveles aceptables para este punto. */
  esperado: VerdictLevel[];
  nota: string;
}

const CASOS: Case[] = [
  {
    nombre: 'Pistas del aeropuerto Madrid-Barajas',
    lat: 40.4719,
    lon: -3.5626,
    altura: 120,
    esperado: ['PROHIBIDO', 'AUTORIZACION'],
    nota: 'Dentro del aeropuerto: nunca debe salir "puedes volar" sin más.',
  },
  {
    nombre: 'Puerta del Sol, Madrid',
    lat: 40.4169,
    lon: -3.7035,
    altura: 120,
    esperado: ['PROHIBIDO', 'AUTORIZACION', 'CONDICIONES'],
    nota: 'Centro urbano y espacio aéreo controlado.',
  },
  {
    nombre: 'Aeropuerto de Barcelona-El Prat',
    lat: 41.2974,
    lon: 2.0833,
    altura: 120,
    esperado: ['PROHIBIDO', 'AUTORIZACION'],
    nota: 'Entorno de aeródromo.',
  },
  {
    nombre: 'Sagrada Familia, Barcelona',
    lat: 41.4036,
    lon: 2.1744,
    altura: 120,
    esperado: ['PROHIBIDO', 'AUTORIZACION', 'CONDICIONES'],
    nota: 'Entorno urbano denso.',
  },
  {
    nombre: 'Campo abierto en Los Monegros (Huesca)',
    lat: 41.5155,
    lon: -0.2262,
    altura: 120,
    esperado: ['LIBRE'],
    nota:
      'Zona rural sin zonas que apliquen a 120 m. Si aquí sale "autorización" es que el aviso ' +
      'general de entorno urbano se está colando en el veredicto.',
  },
  {
    nombre: 'Los Monegros volando a 400 m (por encima del límite legal)',
    lat: 41.5155,
    lon: -0.2262,
    altura: 400,
    esperado: ['AUTORIZACION', 'CONDICIONES', 'PROHIBIDO'],
    nota:
      'A 400 m ya se entra en espacio aéreo superior: comprueba que la altura cambia el veredicto ' +
      'de verdad y no es un adorno.',
  },
];

const COLORS = {
  ok: '\x1b[32m',
  fail: '\x1b[31m',
  dim: '\x1b[90m',
  bold: '\x1b[1m',
  reset: '\x1b[0m',
};

async function main() {
  console.log(`${COLORS.bold}Verificación del motor contra el servicio real de ENAIRE${COLORS.reset}\n`);

  let fallos = 0;

  for (const caso of CASOS) {
    process.stdout.write(`• ${caso.nombre} … `);
    try {
      const [{ zones, failedLayers }, elev] = await Promise.all([
        queryZonesAt(caso.lat, caso.lon),
        getTerrainElevation(caso.lat, caso.lon),
      ]);

      const evaluated = evaluateZones(zones, caso.altura, elev);
      const verdict = buildVerdict(evaluated, caso.altura, failedLayers);
      const ok = caso.esperado.includes(verdict.level);
      if (!ok) fallos++;

      // Ninguna zona marcada como aviso general puede colarse en el veredicto.
      const avisoEnVeredicto = [...verdict.affecting, ...verdict.notAffecting].some((z) => z.advisory);
      if (avisoEnVeredicto) {
        fallos++;
        console.log(`  ${COLORS.fail}Un aviso general se ha colado en el veredicto${COLORS.reset}`);
      }

      console.log(
        `${ok ? COLORS.ok + 'OK' : COLORS.fail + 'FALLO'}${COLORS.reset} ` +
          `${COLORS.dim}(${verdict.level}; ${zones.length} zonas; terreno ${elev === null ? '?' : Math.round(elev) + ' m'})${COLORS.reset}`,
      );
      console.log(`  ${COLORS.dim}${verdict.summary}${COLORS.reset}`);
      if (verdict.advisories.length) {
        console.log(`  ${COLORS.dim}avisos generales mostrados aparte: ${verdict.advisories.length}${COLORS.reset}`);
      }
      if (failedLayers.length) {
        console.log(`  ${COLORS.fail}Capas sin respuesta: ${failedLayers.join(', ')}${COLORS.reset}`);
      }
      for (const z of verdict.affecting.slice(0, 4)) {
        console.log(`  ${COLORS.dim}- [${z.type}] ${z.title} · ${z.vertical.explanation.slice(0, 90)}…${COLORS.reset}`);
      }
      if (!ok) {
        console.log(`  ${COLORS.fail}Esperado uno de: ${caso.esperado.join(', ')} — ${caso.nota}${COLORS.reset}`);
      }
      console.log('');
    } catch (err) {
      fallos++;
      console.log(`${COLORS.fail}ERROR${COLORS.reset} ${(err as Error).message}\n`);
    }
  }

  /* ---------------------------------------------------------------- */
  /* Comprobaciones del motor con datos sintéticos                       */
  /* ---------------------------------------------------------------- */

  console.log(`${COLORS.bold}Comprobaciones del motor${COLORS.reset}\n`);

  const check = (nombre: string, ok: boolean, detalle = '') => {
    if (!ok) fallos++;
    console.log(`${ok ? COLORS.ok + 'OK   ' : COLORS.fail + 'FALLO'}${COLORS.reset} ${nombre}${detalle ? ` ${COLORS.dim}${detalle}${COLORS.reset}` : ''}`);
  };

  const zonaFalsa = (attrs: Partial<RawZoneAttributes>) =>
    normalizeZone({ identifier: 'TEST', type: 'REQ_AUTHORIZATION', uom: 'M', ...attrs }, 'aero', 0);

  // 1. LO MÁS IMPORTANTE: si una capa no responde y no se ha encontrado nada
  //    grave, la app NO puede decir "puedes volar".
  {
    const v = buildVerdict([], 120, ['aero']);
    check(
      'una capa caída nunca produce "Puedes volar"',
      v.level === 'DESCONOCIDO' && v.incomplete,
      `→ ${v.level}`,
    );
  }
  {
    const v = buildVerdict([], 120, []);
    check('sin capas caídas y sin zonas sí se puede volar', v.level === 'LIBRE', `→ ${v.level}`);
  }
  {
    // Una zona prohibida sigue mandando aunque falte una capa: es lo restrictivo.
    const zona = zonaFalsa({ type: 'PROHIBITED', lower: 0, lowerReference: 'AGL', upper: 900, upperReference: 'AGL' });
    const v = buildVerdict(evaluateZones([zona], 120, 500), 120, ['urbano']);
    check('una zona prohibida manda aunque falte una capa', v.level === 'PROHIBIDO', `→ ${v.level}`);
  }

  // 2. Unidad desconocida: no se puede asumir que sean metros.
  {
    const zona = zonaFalsa({ uom: '', lower: 300, lowerReference: 'AGL', upper: 900, upperReference: 'AGL' });
    const [ev] = evaluateZones([zona], 120, 500);
    check('con unidad desconocida la zona se considera aplicable', ev.vertical.affects);
  }
  {
    const zona = zonaFalsa({ uom: 'M', lower: 300, lowerReference: 'AGL', upper: 900, upperReference: 'AGL' });
    const [ev] = evaluateZones([zona], 120, 500);
    check('en metros, una zona que empieza a 300 m no afecta a un vuelo de 120 m', !ev.vertical.affects);
  }

  // 3. W84 no se convierte a ciegas contra una elevación ortométrica.
  {
    const zona = zonaFalsa({ lower: 500, lowerReference: 'W84', upper: 2000, upperReference: 'W84' });
    const [ev] = evaluateZones([zona], 120, 500);
    check('una zona referida a W84 se considera aplicable', ev.vertical.affects);
  }

  // 4. Sin elevación del terreno, una zona en AMSL debe considerarse aplicable.
  {
    const zona = zonaFalsa({ lower: 1000, lowerReference: 'AMSL', upper: 2000, upperReference: 'AMSL' });
    const [ev] = evaluateZones([zona], 120, null);
    check('sin elevación del terreno, una zona AMSL se considera aplicable', ev.vertical.affects);
  }

  // 5. Fechas sin zona horaria: se interpretan como UTC y con margen.
  {
    const haceDosHoras = new Date(Date.now() - 2 * 3600e3).toISOString().slice(0, 19);
    const zona = zonaFalsa({ endDateTime: haceDosHoras, lower: 0, lowerReference: 'AGL' });
    const [ev] = evaluateZones([zona], 120, 500, new Date());
    check('una zona recién terminada no se descarta de inmediato', ev.timing !== 'CADUCADA', `→ ${ev.timing}`);
  }

  // 6. Los avisos generales se reconocen por identificador, no por capa entera.
  {
    const aviso = normalizeZone({ identifier: 'NPDRID', type: 'REQ_AUTHORIZATION', uom: 'M' }, 'urbano', 0);
    const zonaReal = normalizeZone({ identifier: 'URB0001', type: 'REQ_AUTHORIZATION', uom: 'M', lower: 0, lowerReference: 'AGL' }, 'urbano', 1);
    check('NPDRID se trata como aviso general', aviso.advisory);
    check('una zona urbana nueva SÍ contaría para el veredicto', !zonaReal.advisory);
  }

  console.log('');

  // Comprobación de la limpieza de HTML (no debe quedar marcado).
  const muestra =
    '<b>Zona</b><p>Texto con <font color="#dc143c">color</font> y <elem>etiqueta propia</elem>.</p><br/>Fin&nbsp;&amp; ya';
  const limpio = htmlToText(muestra);
  const sinEtiquetas = !/[<>]/.test(limpio) && !limpio.includes('&nbsp;');
  console.log(
    `${sinEtiquetas ? COLORS.ok + 'OK' : COLORS.fail + 'FALLO'}${COLORS.reset} limpieza de HTML → ${JSON.stringify(limpio)}`,
  );
  if (!sinEtiquetas) fallos++;

  console.log(
    `\n${fallos === 0 ? COLORS.ok + 'Todo correcto' : COLORS.fail + fallos + ' comprobación(es) fallidas'}${COLORS.reset}`,
  );
  process.exit(fallos === 0 ? 0 : 1);
}

main();
