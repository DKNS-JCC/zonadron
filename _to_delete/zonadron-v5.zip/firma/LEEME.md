# Clave de firma

`zonadron.keystore` es la clave con la que se firma el APK. Contraseña: `zonadron`
(tanto del almacén como de la clave, alias `zonadron`).

**Guárdala.** Android sólo deja actualizar una app instalada si la nueva versión
está firmada con la MISMA clave. Si la pierdes, para instalar una versión nueva
habría que desinstalar la anterior primero (y se perderían los ajustes guardados).

No hace falta para nada más: no es una clave de Google Play ni de ningún servicio.
