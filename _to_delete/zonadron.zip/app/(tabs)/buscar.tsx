import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Keyboard,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { ScreenScroll } from '../../src/components/Screen';
import { Banner, Card, SectionTitle } from '../../src/components/ui';
import { usePalette } from '../../src/hooks/useTheme';
import { searchPlaces, type Place } from '../../src/api/geocode';
import { radius } from '../../src/theme';

export default function BuscarScreen() {
  const p = usePalette();
  const router = useRouter();
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Place[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [searched, setSearched] = useState(false);
  const abortRef = useRef<AbortController | null>(null);

  const run = useCallback(async (text: string) => {
    abortRef.current?.abort();
    const controller = new AbortController();
    abortRef.current = controller;
    if (text.trim().length < 3) {
      setResults([]);
      setSearched(false);
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const places = await searchPlaces(text, controller.signal);
      if (controller.signal.aborted) return;
      setResults(places);
      setSearched(true);
    } catch (err) {
      if (controller.signal.aborted) return;
      setError('No se ha podido buscar. Comprueba tu conexión e inténtalo de nuevo.');
    } finally {
      if (!controller.signal.aborted) setLoading(false);
    }
  }, []);

  // Búsqueda con retardo, para no saturar el servicio de geocodificación.
  useEffect(() => {
    const t = setTimeout(() => run(query), 550);
    return () => clearTimeout(t);
  }, [query, run]);

  useEffect(() => () => abortRef.current?.abort(), []);

  const open = (place: Place) => {
    Keyboard.dismiss();
    router.push({
      pathname: '/resultado',
      params: { lat: String(place.lat), lon: String(place.lon), label: place.name },
    });
  };

  return (
    <ScreenScroll>
      <View style={{ gap: 4 }}>
        <Text style={{ color: p.text, fontSize: 30, fontWeight: '800', letterSpacing: -0.7 }}>
          Buscar un lugar
        </Text>
        <Text style={{ color: p.textMuted, fontSize: 14.5, lineHeight: 21 }}>
          Escribe una dirección, un municipio o unas coordenadas para consultar ese punto.
        </Text>
      </View>

      <View
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          gap: 10,
          backgroundColor: p.card,
          borderRadius: radius.pill,
          paddingHorizontal: 16,
          borderWidth: StyleSheet.hairlineWidth,
          borderColor: p.cardBorder,
        }}
      >
        <Ionicons name="search" size={18} color={p.textFaint} />
        <TextInput
          value={query}
          onChangeText={setQuery}
          placeholder="Ej. Playa de la Malvarrosa, o 39.47, -0.32"
          placeholderTextColor={p.textFaint}
          autoCorrect={false}
          returnKeyType="search"
          onSubmitEditing={() => run(query)}
          accessibilityLabel="Buscar un lugar"
          style={{ flex: 1, color: p.text, fontSize: 15, paddingVertical: 14 }}
        />
        {query.length > 0 ? (
          <Pressable onPress={() => setQuery('')} hitSlop={10} accessibilityLabel="Borrar">
            <Ionicons name="close-circle" size={18} color={p.textFaint} />
          </Pressable>
        ) : null}
      </View>

      {loading ? (
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, paddingHorizontal: 4 }}>
          <ActivityIndicator color={p.accent} size="small" />
          <Text style={{ color: p.textMuted, fontSize: 13 }}>Buscando…</Text>
        </View>
      ) : null}

      {error ? <Banner tone="warn">{error}</Banner> : null}

      {results.length > 0 ? (
        <View style={{ gap: 10 }}>
          <SectionTitle>Resultados</SectionTitle>
          {results.map((place) => (
            <Pressable key={place.id} onPress={() => open(place)} accessibilityRole="button">
              {({ pressed }) => (
                <Card style={{ opacity: pressed ? 0.7 : 1 }}>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
                    <Ionicons name="location-outline" size={20} color={p.accent} />
                    <View style={{ flex: 1 }}>
                      <Text style={{ color: p.text, fontSize: 15.5, fontWeight: '700' }} numberOfLines={1}>
                        {place.name}
                      </Text>
                      {place.detail ? (
                        <Text style={{ color: p.textMuted, fontSize: 12.5, marginTop: 1 }} numberOfLines={2}>
                          {place.detail}
                        </Text>
                      ) : null}
                    </View>
                    <Ionicons name="chevron-forward" size={18} color={p.textFaint} />
                  </View>
                </Card>
              )}
            </Pressable>
          ))}
        </View>
      ) : null}

      {searched && !loading && results.length === 0 && !error ? (
        <Banner>No se ha encontrado ningún lugar con ese nombre en España.</Banner>
      ) : null}

      <Banner>
        La búsqueda de lugares usa OpenStreetMap sólo para convertir un nombre en coordenadas.
        Las zonas de vuelo siempre se consultan a ENAIRE.
      </Banner>
    </ScreenScroll>
  );
}
