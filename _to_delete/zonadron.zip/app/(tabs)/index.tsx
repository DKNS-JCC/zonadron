import React, { useCallback, useEffect, useRef, useState } from 'react';
import { ActivityIndicator, Platform, RefreshControl, Text, View } from 'react-native';
import * as Location from 'expo-location';
import * as Haptics from 'expo-haptics';
import { Ionicons } from '@expo/vector-icons';
import { ScreenScroll } from '../../src/components/Screen';
import { ResultView } from '../../src/components/ResultView';
import { HeightPicker } from '../../src/components/HeightPicker';
import { Banner, Card, GhostButton, PrimaryButton, SectionTitle } from '../../src/components/ui';
import { usePalette } from '../../src/hooks/useTheme';
import { useSettings } from '../../src/state/SettingsContext';
import { checkPoint } from '../../src/logic/query';
import { describePoint } from '../../src/api/geocode';
import type { Coords, QueryResult } from '../../src/types';

type Phase = 'idle' | 'locating' | 'querying' | 'done' | 'error';

export default function HomeScreen() {
  const p = usePalette();
  const { flightHeight, setFlightHeight, ready } = useSettings();

  const [phase, setPhase] = useState<Phase>('idle');
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<QueryResult | null>(null);
  const [place, setPlace] = useState<string | null>(null);
  const [accuracy, setAccuracy] = useState<number | null>(null);
  const abortRef = useRef<AbortController | null>(null);
  const lastCoords = useRef<Coords | null>(null);

  const runQuery = useCallback(
    async (coords: Coords, height: number) => {
      abortRef.current?.abort();
      const controller = new AbortController();
      abortRef.current = controller;
      setPhase('querying');
      setError(null);
      try {
        const res = await checkPoint(coords, height, controller.signal);
        if (controller.signal.aborted) return;
        setResult(res);
        setPhase('done');
        if (Platform.OS !== 'web') {
          const notify =
            res.verdict.level === 'PROHIBIDO' || res.verdict.level === 'AUTORIZACION'
              ? Haptics.NotificationFeedbackType.Warning
              : Haptics.NotificationFeedbackType.Success;
          Haptics.notificationAsync(notify).catch(() => {});
        }
        describePoint(coords.lat, coords.lon, controller.signal)
          .then((name) => !controller.signal.aborted && setPlace(name))
          .catch(() => {});
      } catch (err) {
        if (controller.signal.aborted) return;
        setError(err instanceof Error ? err.message : 'Error inesperado');
        setPhase('error');
      }
    },
    [],
  );

  const locateAndCheck = useCallback(async () => {
    setPhase('locating');
    setError(null);
    setPlace(null);
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        setError(
          'Necesito acceso a tu ubicación para comprobar dónde estás. Puedes activarlo en los ajustes del móvil, o usar las pestañas Mapa y Buscar para consultar un punto a mano.',
        );
        setPhase('error');
        return;
      }
      const pos = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.High,
      });
      const coords: Coords = { lat: pos.coords.latitude, lon: pos.coords.longitude };
      lastCoords.current = coords;
      setAccuracy(pos.coords.accuracy ?? null);
      await runQuery(coords, flightHeight);
    } catch (err) {
      setError(
        err instanceof Error
          ? `No se ha podido obtener tu ubicación: ${err.message}`
          : 'No se ha podido obtener tu ubicación.',
      );
      setPhase('error');
    }
  }, [flightHeight, runQuery]);

  // Si ya tenemos permiso concedido, comprobamos automáticamente al abrir.
  useEffect(() => {
    if (!ready) return;
    let alive = true;
    Location.getForegroundPermissionsAsync()
      .then(({ status }) => {
        if (alive && status === 'granted') locateAndCheck();
      })
      .catch(() => {});
    return () => {
      alive = false;
      abortRef.current?.abort();
    };
    // Sólo al arrancar.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ready]);

  // Cambiar la altura recalcula el veredicto sobre el mismo punto.
  const onHeightChange = useCallback(
    (h: number) => {
      setFlightHeight(h);
      if (lastCoords.current) runQuery(lastCoords.current, h);
    },
    [runQuery, setFlightHeight],
  );

  const busy = phase === 'locating' || phase === 'querying';

  return (
    <ScreenScroll
      refreshControl={
        <RefreshControl refreshing={false} onRefresh={locateAndCheck} tintColor={p.accent} />
      }
    >
      <View style={{ gap: 4 }}>
        <Text style={{ color: p.text, fontSize: 32, fontWeight: '800', letterSpacing: -0.8 }}>
          ¿Puedo volar aquí?
        </Text>
        <Text style={{ color: p.textMuted, fontSize: 14.5, lineHeight: 21 }}>
          Comprueba tu punto exacto contra las Zonas Geográficas UAS oficiales de ENAIRE.
        </Text>
      </View>

      <PrimaryButton
        label={busy ? (phase === 'locating' ? 'Buscando tu posición…' : 'Consultando a ENAIRE…') : 'Comprobar mi ubicación'}
        icon="locate"
        onPress={locateAndCheck}
        loading={busy}
      />

      <Card>
        <SectionTitle>Altura de vuelo</SectionTitle>
        <HeightPicker value={flightHeight} onChange={onHeightChange} />
        <Text style={{ color: p.textFaint, fontSize: 12, lineHeight: 18, marginTop: 10 }}>
          Metros sobre el terreno. Se usa para descartar las zonas que empiezan por encima de tu
          vuelo: la altura cambia el resultado de verdad, no es decorativa.
        </Text>
      </Card>

      {phase === 'error' && error ? (
        <Card>
          <View style={{ flexDirection: 'row', gap: 10, alignItems: 'flex-start' }}>
            <Ionicons name="alert-circle-outline" size={20} color="#D92D20" style={{ marginTop: 1 }} />
            <View style={{ flex: 1, gap: 12 }}>
              <Text style={{ color: p.text, fontSize: 14, lineHeight: 21 }}>{error}</Text>
              <GhostButton label="Reintentar" icon="refresh" onPress={locateAndCheck} />
            </View>
          </View>
        </Card>
      ) : null}

      {phase === 'querying' && !result ? (
        <Card>
          <View style={{ alignItems: 'center', gap: 12, paddingVertical: 12 }}>
            <ActivityIndicator color={p.accent} />
            <Text style={{ color: p.textMuted, fontSize: 13.5 }}>
              Consultando las tres capas oficiales de ENAIRE…
            </Text>
          </View>
        </Card>
      ) : null}

      {result ? (
        <>
          {accuracy !== null && accuracy > 50 ? (
            <Banner tone="warn">
              Tu posición tiene una precisión de ±{Math.round(accuracy)} m. Si estás cerca del borde
              de una zona, confirma el punto en el mapa.
            </Banner>
          ) : null}
          <ResultView result={result} place={place} />
        </>
      ) : null}
    </ScreenScroll>
  );
}
