import React, { useState } from 'react';
import { Linking, Pressable, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { ScreenScroll } from '../../src/components/Screen';
import { Banner, Card, Divider, SectionTitle } from '../../src/components/ui';
import { usePalette } from '../../src/hooks/useTheme';
import { RULE_SECTIONS, SOURCES } from '../../src/logic/rules';
import { ELEVATION_SOURCE } from '../../src/api/elevation';

export default function InfoScreen() {
  const p = usePalette();
  const [open, setOpen] = useState<string | null>('antes');

  return (
    <ScreenScroll>
      <View style={{ gap: 4 }}>
        <Text style={{ color: p.text, fontSize: 30, fontWeight: '800', letterSpacing: -0.7 }}>
          Normas y fuentes
        </Text>
        <Text style={{ color: p.textMuted, fontSize: 14.5, lineHeight: 21 }}>
          Lo esencial de la normativa española y europea, y de dónde sale cada dato de esta app.
        </Text>
      </View>

      <View style={{ gap: 10 }}>
        {RULE_SECTIONS.map((section) => {
          const expanded = open === section.id;
          return (
            <Card key={section.id}>
              <Pressable
                onPress={() => setOpen(expanded ? null : section.id)}
                accessibilityRole="button"
                accessibilityState={{ expanded }}
                style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}
              >
                <Ionicons name={section.icon as any} size={20} color={p.accent} />
                <Text style={{ color: p.text, fontSize: 16, fontWeight: '700', flex: 1 }}>
                  {section.title}
                </Text>
                <Ionicons name={expanded ? 'chevron-up' : 'chevron-down'} size={18} color={p.textFaint} />
              </Pressable>

              {expanded ? (
                <View style={{ marginTop: 12, gap: 10 }}>
                  <Text style={{ color: p.textMuted, fontSize: 14, lineHeight: 21 }}>
                    {section.intro}
                  </Text>
                  <View style={{ gap: 8 }}>
                    {section.bullets.map((b, i) => (
                      <View key={i} style={{ flexDirection: 'row', gap: 9 }}>
                        <Text style={{ color: p.accent, fontSize: 14, lineHeight: 21 }}>•</Text>
                        <Text style={{ color: p.text, fontSize: 14, lineHeight: 21, flex: 1 }}>{b}</Text>
                      </View>
                    ))}
                  </View>
                  <Divider />
                  <Pressable
                    onPress={() => Linking.openURL(section.sourceUrl).catch(() => {})}
                    style={{ flexDirection: 'row', alignItems: 'center', gap: 7 }}
                  >
                    <Ionicons name="open-outline" size={14} color={p.accent} />
                    <Text style={{ color: p.accent, fontSize: 12.5, flex: 1 }}>{section.source}</Text>
                  </Pressable>
                </View>
              ) : null}
            </Card>
          );
        })}
      </View>

      <Card>
        <SectionTitle>De dónde salen los datos</SectionTitle>
        <Text style={{ color: p.text, fontSize: 14, lineHeight: 21 }}>
          Las zonas se consultan en tiempo real al servicio oficial de ENAIRE (Zonas Geográficas UAS,
          formato ED-318). La app no guarda una copia propia de las zonas ni pasa por ningún servidor
          intermedio: el móvil habla directamente con ENAIRE, así que siempre ves el dato vigente.
        </Text>
        <Divider />
        <Text style={{ color: p.textMuted, fontSize: 13.5, lineHeight: 20 }}>
          La elevación del terreno viene de {ELEVATION_SOURCE} y se usa para convertir los límites
          referidos al nivel del mar en altura real sobre el suelo. La búsqueda de lugares usa
          OpenStreetMap.
        </Text>
        <Divider />
        <View style={{ gap: 8 }}>
          {SOURCES.map((s) => (
            <Pressable
              key={s.url}
              onPress={() => Linking.openURL(s.url).catch(() => {})}
              style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}
            >
              <Ionicons name="link-outline" size={15} color={p.accent} />
              <Text style={{ color: p.accent, fontSize: 13.5, flex: 1, textDecorationLine: 'underline' }}>
                {s.label}
              </Text>
            </Pressable>
          ))}
        </View>
      </Card>

      <Banner tone="warn">
        Esta aplicación es una herramienta de consulta independiente. No sustituye a los servicios
        oficiales de ENAIRE ni a la normativa: la responsabilidad de comprobar que un vuelo es legal
        y seguro es siempre del piloto. Comprueba también los NOTAM antes de volar.
      </Banner>
    </ScreenScroll>
  );
}
