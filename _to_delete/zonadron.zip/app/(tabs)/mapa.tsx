import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { ActivityIndicator, Pressable, StyleSheet, Text, View, useColorScheme } from 'react-native';
import { useRouter } from 'expo-router';
import * as Location from 'expo-location';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MapFrame, type MapFrameHandle } from '../../src/components/MapFrame';
import { usePalette } from '../../src/hooks/useTheme';
import { buildMapHtml } from '../../src/map/mapHtml';
import { getLayerIds } from '../../src/api/enaire';
import { layerColor, layerDescription, layerLabel } from '../../src/logic/labels';
import { radius, shadow } from '../../src/theme';
import type { LayerKey } from '../../src/types';

const ALL_LAYERS: LayerKey[] = ['aero', 'urbano', 'infraestructuras'];

export default function MapaScreen() {
  const p = usePalette();
  const scheme = useColorScheme();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const mapRef = useRef<MapFrameHandle>(null);

  const [layerIds, setLayerIds] = useState<{ aero: number; urbano: number; infraestructuras: number } | null>(null);
  // La capa "urbano" de ENAIRE cubre España entera (son las FIR, ver
  // ADVISORY_LAYERS): pintada por defecto taparía todo el mapa sin aportar nada.
  const [visible, setVisible] = useState<Record<LayerKey, boolean>>({
    aero: true,
    urbano: false,
    infraestructuras: true,
  });
  // Se congela la visibilidad inicial para no recrear el HTML en cada cambio.
  const initialVisible = useRef(visible);
  const [legendOpen, setLegendOpen] = useState(false);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let alive = true;
    getLayerIds()
      .then((ids) => alive && setLayerIds(ids))
      .catch(() => alive && setLayerIds({ aero: 2, urbano: 3, infraestructuras: 0 }));
    return () => {
      alive = false;
    };
  }, []);

  const html = useMemo(
    () =>
      layerIds
        ? buildMapHtml({
            lat: 40.4168,
            lon: -3.7038,
            zoom: 11,
            layerIds,
            visible: initialVisible.current,
            dark: scheme === 'dark',
          })
        : null,
    [layerIds, scheme],
  );

  const send = useCallback((msg: object) => {
    mapRef.current?.post(msg);
  }, []);

  const toggleLayer = useCallback(
    (key: LayerKey) => {
      setVisible((prev) => {
        const next = { ...prev, [key]: !prev[key] };
        send({ type: 'layers', visible: next });
        return next;
      });
    },
    [send],
  );

  const goToMyLocation = useCallback(async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') return;
      const pos = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High });
      send({ type: 'center', lat: pos.coords.latitude, lon: pos.coords.longitude, zoom: 15, marker: false });
      if (pos.coords.accuracy) {
        send({ type: 'accuracy', lat: pos.coords.latitude, lon: pos.coords.longitude, radius: pos.coords.accuracy });
      }
    } catch {
      /* silencioso: el usuario puede mover el mapa a mano */
    }
  }, [send]);

  const onMessage = useCallback(
    (data: unknown) => {
      const msg = data as { type?: string; lat?: number; lon?: number };
      if (msg.type === 'ready') {
        setReady(true);
        return;
      }
      if (msg.type === 'pick') {
        router.push({
          pathname: '/resultado',
          params: { lat: String(msg.lat), lon: String(msg.lon) },
        });
      }
    },
    [router],
  );

  return (
    <View style={{ flex: 1, backgroundColor: p.bg }}>
      {html ? (
        <MapFrame ref={mapRef} html={html} onMessage={onMessage} style={{ backgroundColor: p.bg }} />
      ) : (
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12 }}>
          <ActivityIndicator color={p.accent} />
          <Text style={{ color: p.textMuted, fontSize: 13 }}>Preparando el mapa oficial…</Text>
        </View>
      )}

      {/* Cabecera flotante */}
      <View style={{ position: 'absolute', top: insets.top + 8, left: 12, right: 12, gap: 8 }}>
        <View
          style={[
            {
              backgroundColor: p.tabBar,
              borderRadius: radius.md,
              paddingHorizontal: 14,
              paddingVertical: 10,
              borderWidth: StyleSheet.hairlineWidth,
              borderColor: p.cardBorder,
              flexDirection: 'row',
              alignItems: 'center',
              gap: 8,
            },
            shadow,
          ]}
        >
          <Ionicons name="layers-outline" size={16} color={p.textMuted} />
          <Text style={{ color: p.text, fontSize: 13, fontWeight: '600', flex: 1 }}>
            Zonas UAS oficiales de ENAIRE
          </Text>
          <Pressable onPress={() => setLegendOpen((v) => !v)} hitSlop={10} accessibilityRole="button">
            <Ionicons name={legendOpen ? 'chevron-up' : 'information-circle-outline'} size={19} color={p.accent} />
          </Pressable>
        </View>

        {legendOpen ? (
          <View
            style={[
              {
                backgroundColor: p.card,
                borderRadius: radius.md,
                padding: 14,
                borderWidth: StyleSheet.hairlineWidth,
                borderColor: p.cardBorder,
                gap: 10,
              },
              shadow,
            ]}
          >
            {ALL_LAYERS.map((key) => (
              <Pressable
                key={key}
                onPress={() => toggleLayer(key)}
                style={{ flexDirection: 'row', gap: 10, alignItems: 'flex-start' }}
                accessibilityRole="switch"
                accessibilityState={{ checked: visible[key] }}
              >
                <Ionicons
                  name={visible[key] ? 'checkbox' : 'square-outline'}
                  size={19}
                  color={visible[key] ? layerColor[key] : p.textFaint}
                  style={{ marginTop: 1 }}
                />
                <View style={{ flex: 1 }}>
                  <Text style={{ color: p.text, fontSize: 13.5, fontWeight: '700' }}>{layerLabel[key]}</Text>
                  <Text style={{ color: p.textMuted, fontSize: 12, lineHeight: 17 }}>
                    {layerDescription[key]}
                  </Text>
                </View>
              </Pressable>
            ))}
            <Text style={{ color: p.textFaint, fontSize: 11.5, lineHeight: 16 }}>
              El dibujo de las zonas se pide directamente al servicio de ENAIRE, así que es el mismo
              que verías en su visor oficial. Los colores los define ENAIRE, no esta app.
            </Text>
          </View>
        ) : null}
      </View>

      {/* Botones flotantes */}
      <View style={{ position: 'absolute', right: 12, bottom: insets.bottom + 96, gap: 10 }}>
        <FloatingButton icon="locate" onPress={goToMyLocation} palette={p} />
      </View>

      <View style={{ position: 'absolute', left: 12, right: 12, bottom: insets.bottom + 20 }}>
        <Pressable
          onPress={() => send({ type: 'pickCenter' })}
          disabled={!ready}
          accessibilityRole="button"
          style={({ pressed }) => [
            {
              backgroundColor: p.accent,
              opacity: !ready ? 0.5 : pressed ? 0.85 : 1,
              borderRadius: radius.pill,
              paddingVertical: 15,
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'center',
              gap: 9,
            },
            shadow,
          ]}
        >
          <Ionicons name="scan-outline" size={19} color="#fff" />
          <Text style={{ color: '#fff', fontWeight: '700', fontSize: 15 }}>
            Consultar el punto de la cruz
          </Text>
        </Pressable>
      </View>
    </View>
  );
}

function FloatingButton({
  icon,
  onPress,
  palette,
}: {
  icon: keyof typeof Ionicons.glyphMap;
  onPress: () => void;
  palette: ReturnType<typeof usePalette>;
}) {
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      style={({ pressed }) => [
        {
          width: 46,
          height: 46,
          borderRadius: 23,
          backgroundColor: pressed ? palette.accentSoft : palette.card,
          alignItems: 'center',
          justifyContent: 'center',
          borderWidth: StyleSheet.hairlineWidth,
          borderColor: palette.cardBorder,
        },
        shadow,
      ]}
    >
      <Ionicons name={icon} size={21} color={palette.accent} />
    </Pressable>
  );
}
