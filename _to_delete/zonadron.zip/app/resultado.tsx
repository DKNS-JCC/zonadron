import React, { useCallback, useEffect, useRef, useState } from 'react';
import { ActivityIndicator, Text, View } from 'react-native';
import { useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { ScreenScroll } from '../src/components/Screen';
import { ResultView } from '../src/components/ResultView';
import { HeightPicker } from '../src/components/HeightPicker';
import { Card, GhostButton, SectionTitle } from '../src/components/ui';
import { usePalette } from '../src/hooks/useTheme';
import { useSettings } from '../src/state/SettingsContext';
import { checkPoint } from '../src/logic/query';
import { describePoint } from '../src/api/geocode';
import type { QueryResult } from '../src/types';

export default function ResultadoScreen() {
  const p = usePalette();
  const params = useLocalSearchParams<{ lat?: string; lon?: string; label?: string }>();
  const { flightHeight, setFlightHeight } = useSettings();

  const lat = Number(params.lat);
  const lon = Number(params.lon);
  const valid = Number.isFinite(lat) && Number.isFinite(lon);

  const [result, setResult] = useState<QueryResult | null>(null);
  const [place, setPlace] = useState<string | null>(params.label ?? null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const abortRef = useRef<AbortController | null>(null);

  const run = useCallback(
    async (height: number) => {
      if (!valid) return;
      abortRef.current?.abort();
      const controller = new AbortController();
      abortRef.current = controller;
      setLoading(true);
      setError(null);
      try {
        const res = await checkPoint({ lat, lon }, height, controller.signal);
        if (controller.signal.aborted) return;
        setResult(res);
      } catch (err) {
        if (controller.signal.aborted) return;
        setError(err instanceof Error ? err.message : 'Error inesperado');
      } finally {
        if (!controller.signal.aborted) setLoading(false);
      }
    },
    [lat, lon, valid],
  );

  useEffect(() => {
    run(flightHeight);
    if (!params.label) {
      describePoint(lat, lon)
        .then(setPlace)
        .catch(() => {});
    }
    return () => abortRef.current?.abort();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lat, lon]);

  if (!valid) {
    return (
      <ScreenScroll>
        <Card>
          <Text style={{ color: p.text }}>No se han recibido coordenadas válidas.</Text>
        </Card>
      </ScreenScroll>
    );
  }

  return (
    <ScreenScroll>
      <Card>
        <SectionTitle>Altura de vuelo</SectionTitle>
        <HeightPicker
          value={flightHeight}
          compact
          onChange={(h) => {
            setFlightHeight(h);
            run(h);
          }}
        />
      </Card>

      {loading && !result ? (
        <Card>
          <View style={{ alignItems: 'center', gap: 12, paddingVertical: 16 }}>
            <ActivityIndicator color={p.accent} />
            <Text style={{ color: p.textMuted, fontSize: 13.5 }}>Consultando a ENAIRE…</Text>
          </View>
        </Card>
      ) : null}

      {error ? (
        <Card>
          <View style={{ flexDirection: 'row', gap: 10, alignItems: 'flex-start' }}>
            <Ionicons name="alert-circle-outline" size={20} color="#D92D20" style={{ marginTop: 1 }} />
            <View style={{ flex: 1, gap: 12 }}>
              <Text style={{ color: p.text, fontSize: 14, lineHeight: 21 }}>{error}</Text>
              <GhostButton label="Reintentar" icon="refresh" onPress={() => run(flightHeight)} />
            </View>
          </View>
        </Card>
      ) : null}

      {result ? <ResultView result={result} place={place} /> : null}
    </ScreenScroll>
  );
}
