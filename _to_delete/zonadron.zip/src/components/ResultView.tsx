import React, { useMemo, useState } from 'react';
import { Linking, Pressable, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { usePalette } from '../hooks/useTheme';
import type { LayerKey, QueryResult } from '../types';
import { VerdictCard } from './VerdictCard';
import { ZoneCard } from './ZoneCard';
import { Banner, Card, InfoRow, SectionTitle } from './ui';
import { layerLabel } from '../logic/labels';
import { ENAIRE_DRONES_URL } from '../api/enaire';
import { ELEVATION_SOURCE } from '../api/elevation';

function fmtCoord(n: number) {
  return n.toFixed(5);
}

export function ResultView({
  result,
  place,
}: {
  result: QueryResult;
  place?: string | null;
}) {
  const p = usePalette();
  const [showOthers, setShowOthers] = useState(false);

  const affecting = result.verdict.affecting;
  const others = result.verdict.notAffecting;
  const expired = result.zones.filter((z) => z.timing === 'CADUCADA');

  const queriedAt = useMemo(
    () => new Date(result.queriedAt).toLocaleString('es-ES', { dateStyle: 'medium', timeStyle: 'short' }),
    [result.queriedAt],
  );

  return (
    <View style={{ gap: 16 }}>
      <VerdictCard result={result} place={place} />

      {result.failedLayers.length > 0 ? (
        <Banner tone="warn">
          No se ha podido consultar {result.failedLayers.map((l: LayerKey) => layerLabel[l]).join(', ')}.
          El resultado está incompleto: vuelve a intentarlo antes de volar.
        </Banner>
      ) : null}

      {result.terrainElevation === null ? (
        <Banner tone="warn">
          No se ha podido obtener la elevación del terreno en este punto. Las zonas con límites
          referidos al nivel del mar se muestran como si te afectaran, por prudencia.
        </Banner>
      ) : null}

      {affecting.length > 0 ? (
        <View style={{ gap: 12 }}>
          <SectionTitle>
            {affecting.length === 1 ? 'La zona que te afecta' : `Las ${affecting.length} zonas que te afectan`}
          </SectionTitle>
          {affecting.map((z) => (
            <ZoneCard key={z.key} zone={z} />
          ))}
        </View>
      ) : null}

      {others.length > 0 ? (
        <View style={{ gap: 12 }}>
          <Pressable
            onPress={() => setShowOthers((v) => !v)}
            accessibilityRole="button"
            style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}
          >
            <Ionicons name={showOthers ? 'chevron-down' : 'chevron-forward'} size={17} color={p.textMuted} />
            <Text style={{ color: p.textMuted, fontSize: 12, fontWeight: '700', letterSpacing: 0.9, textTransform: 'uppercase', flex: 1 }}>
              {others.length} {others.length === 1 ? 'zona que no te afecta' : 'zonas que no te afectan'} a esta altura
            </Text>
          </Pressable>
          {showOthers ? others.map((z) => <ZoneCard key={z.key} zone={z} dimmed />) : null}
        </View>
      ) : null}

      {result.verdict.advisories.length > 0 ? (
        <View style={{ gap: 12 }}>
          <SectionTitle>Avisos que ENAIRE publica para toda España</SectionTitle>
          {result.verdict.advisories.map((z) => (
            <ZoneCard key={z.key} zone={z} />
          ))}
        </View>
      ) : null}

      {expired.length > 0 ? (
        <View style={{ gap: 12 }}>
          <SectionTitle>Zonas ya no vigentes</SectionTitle>
          {expired.map((z) => (
            <ZoneCard key={z.key} zone={z} dimmed />
          ))}
        </View>
      ) : null}

      <Card>
        <SectionTitle>Datos de la consulta</SectionTitle>
        <InfoRow label="Coordenadas" value={`${fmtCoord(result.coords.lat)}, ${fmtCoord(result.coords.lon)}`} mono />
        <InfoRow
          label="Elevación del terreno"
          value={result.terrainElevation === null ? 'No disponible' : `${Math.round(result.terrainElevation)} m sobre el nivel del mar`}
          mono
        />
        <InfoRow
          label="Tu dron llegaría a"
          value={
            result.terrainElevation === null
              ? `${result.flightHeightAgl} m sobre el terreno`
              : `${Math.round(result.terrainElevation + result.flightHeightAgl)} m sobre el nivel del mar`
          }
          mono
        />
        <InfoRow
          label="Zonas encontradas en el punto"
          value={`${result.zones.filter((z) => !z.advisory).length} (+${result.verdict.advisories.length} aviso general)`}
          mono
        />
        <InfoRow label="Consultado" value={queriedAt} />
        <InfoRow label="Origen de las zonas" value="ENAIRE · Zonas Geográficas UAS (ED-318)" />
        <InfoRow label="Origen de la elevación" value={ELEVATION_SOURCE} />
      </Card>

      <Banner>
        Esta app consulta en directo el servicio oficial de ENAIRE, pero no lo sustituye. Antes de
        volar comprueba también NOTAM y avisos vigentes, y recuerda que la responsabilidad del vuelo
        siempre es del piloto.{' '}
        <Text
          style={{ color: p.accent, textDecorationLine: 'underline' }}
          onPress={() => Linking.openURL(ENAIRE_DRONES_URL).catch(() => {})}
        >
          Abrir ENAIRE Drones
        </Text>
      </Banner>
    </View>
  );
}
