import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { usePalette } from '../hooks/useTheme';
import { radius, shadow, verdictBg, verdictStyles } from '../theme';
import type { QueryResult } from '../types';

export function VerdictCard({ result, place }: { result: QueryResult; place?: string | null }) {
  const p = usePalette();
  const style = verdictStyles[result.verdict.level];
  const bg = verdictBg(result.verdict.level, p);

  return (
    <View
      style={[
        {
          backgroundColor: bg,
          borderRadius: radius.lg,
          borderWidth: StyleSheet.hairlineWidth,
          borderColor: style.color + '55',
          padding: 20,
        },
        shadow,
      ]}
    >
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
        <View
          style={{
            width: 48,
            height: 48,
            borderRadius: 24,
            backgroundColor: style.color,
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <Ionicons name={style.icon as keyof typeof Ionicons.glyphMap} size={28} color="#fff" />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={{ color: style.color, fontSize: 24, fontWeight: '800', letterSpacing: -0.4 }}>
            {result.verdict.headline}
          </Text>
          <Text style={{ color: p.textMuted, fontSize: 12.5, marginTop: 2 }}>
            volando hasta {result.flightHeightAgl} m sobre el terreno
          </Text>
        </View>
      </View>

      <Text style={{ color: p.text, fontSize: 15, lineHeight: 22, marginTop: 14 }}>
        {result.verdict.summary}
      </Text>

      {place ? (
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 12 }}>
          <Ionicons name="location-outline" size={14} color={p.textMuted} />
          <Text style={{ color: p.textMuted, fontSize: 12.5, flex: 1 }} numberOfLines={2}>
            {place}
          </Text>
        </View>
      ) : null}
    </View>
  );
}
