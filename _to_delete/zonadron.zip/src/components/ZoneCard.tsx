import React, { useState } from 'react';
import { Linking, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { usePalette } from '../hooks/useTheme';
import { radius, shadow, verdictStyles } from '../theme';
import type { EvaluatedZone } from '../types';
import {
  layerColor,
  layerLabel,
  reasonExplain,
  reasonLabel,
  zoneTypeExplain,
  zoneTypeLabel,
} from '../logic/labels';
import { actionAdvice, rawBandLabel, verticalBandLabel } from '../logic/verdict';
import { toParagraphs } from '../logic/html';
import { Chip, Divider } from './ui';

const TYPE_COLOR: Record<string, string> = {
  PROHIBITED: verdictStyles.PROHIBIDO.color,
  REQ_AUTHORIZATION: verdictStyles.AUTORIZACION.color,
  CONDITIONAL: verdictStyles.CONDICIONES.color,
  NO_RESTRICTION: verdictStyles.LIBRE.color,
  UNKNOWN: verdictStyles.DESCONOCIDO.color,
};

export function ZoneCard({ zone, dimmed }: { zone: EvaluatedZone; dimmed?: boolean }) {
  const p = usePalette();
  const [openOfficial, setOpenOfficial] = useState(false);
  const [openDetails, setOpenDetails] = useState(false);
  const color = TYPE_COLOR[zone.type] ?? p.textMuted;
  const paragraphs = toParagraphs(zone.officialText);

  const contactLinks: Array<{ icon: keyof typeof Ionicons.glyphMap; text: string; url: string }> = [];
  if (zone.contact.email) contactLinks.push({ icon: 'mail-outline', text: zone.contact.email, url: `mailto:${zone.contact.email}` });
  if (zone.contact.phone) contactLinks.push({ icon: 'call-outline', text: zone.contact.phone, url: `tel:${zone.contact.phone.replace(/\s+/g, '')}` });
  if (zone.contact.url) contactLinks.push({ icon: 'globe-outline', text: zone.contact.url, url: zone.contact.url });

  return (
    <View
      style={[
        {
          backgroundColor: p.card,
          borderRadius: radius.lg,
          borderWidth: StyleSheet.hairlineWidth,
          borderColor: p.cardBorder,
          borderLeftWidth: 4,
          borderLeftColor: dimmed ? p.cardBorder : zone.advisory ? p.accent : color,
          padding: 16,
          opacity: dimmed ? 0.72 : 1,
        },
        shadow,
      ]}
    >
      <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap', marginBottom: 8 }}>
        {zone.advisory ? (
          <Chip label="Aviso general" color={p.accent} icon="megaphone-outline" small />
        ) : (
          <Chip label={zoneTypeLabel[zone.type]} color={dimmed ? p.textMuted : color} icon="shield-outline" small />
        )}
        <Chip label={layerLabel[zone.layer]} color={layerColor[zone.layer]} small />
        {zone.timing !== 'PERMANENTE' ? (
          <Chip label={zone.timing === 'CADUCADA' ? 'No vigente' : 'Aplicación limitada'} color="#C77700" icon="time-outline" small />
        ) : null}
      </View>

      <Text style={{ color: p.text, fontSize: 17, fontWeight: '700', letterSpacing: -0.2 }}>
        {zone.title}
      </Text>
      <Text style={{ color: p.textFaint, fontSize: 11.5, marginTop: 2 }}>
        {zone.identifier}
      </Text>

      {!zone.advisory ? (
        <Text style={{ color: p.text, fontSize: 14, lineHeight: 21, marginTop: 10 }}>
          {zoneTypeExplain[zone.type]}
        </Text>
      ) : null}

      {zone.reasons.length > 0 && !zone.advisory ? (
        <Text style={{ color: p.textMuted, fontSize: 13.5, lineHeight: 20, marginTop: 8 }}>
          {zone.reasons.map((r) => reasonExplain[r] ?? `Motivo: ${reasonLabel[r] ?? r}.`).join(' ')}
        </Text>
      ) : null}

      <View
        style={{
          marginTop: 12,
          backgroundColor: p.accentSoft,
          borderRadius: radius.md,
          padding: 12,
          flexDirection: 'row',
          gap: 9,
        }}
      >
        <Ionicons name="navigate-circle-outline" size={17} color={p.accent} style={{ marginTop: 1 }} />
        <Text style={{ color: p.text, fontSize: 13.5, lineHeight: 20, flex: 1 }}>
          {actionAdvice(zone)}
        </Text>
      </View>

      {contactLinks.length > 0 ? (
        <View style={{ marginTop: 10, gap: 6 }}>
          {contactLinks.map((c) => (
            <Pressable
              key={c.url}
              onPress={() => Linking.openURL(c.url).catch(() => {})}
              style={{ flexDirection: 'row', alignItems: 'center', gap: 7 }}
            >
              <Ionicons name={c.icon} size={14} color={p.accent} />
              <Text style={{ color: p.accent, fontSize: 13, textDecorationLine: 'underline', flex: 1 }} numberOfLines={1}>
                {c.text}
              </Text>
            </Pressable>
          ))}
        </View>
      ) : null}

      {!zone.advisory ? (
        <>
          <View
            style={{
              marginTop: 12,
              flexDirection: 'row',
              alignItems: 'center',
              gap: 8,
            }}
          >
            <Ionicons name="swap-vertical-outline" size={15} color={p.textMuted} />
            <Text style={{ color: p.textMuted, fontSize: 13, flex: 1 }}>{verticalBandLabel(zone)}</Text>
          </View>

          <Text style={{ color: p.textFaint, fontSize: 12, lineHeight: 18, marginTop: 6 }}>
            {zone.vertical.explanation}
          </Text>
        </>
      ) : null}

      {zone.timingNote ? (
        <Text style={{ color: '#C77700', fontSize: 12.5, lineHeight: 18, marginTop: 8 }}>
          {zone.timingNote}
        </Text>
      ) : null}

      <Divider />

      <Pressable
        onPress={() => setOpenOfficial((v) => !v)}
        style={{ flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 4 }}
        accessibilityRole="button"
      >
        <Ionicons name={openOfficial ? 'chevron-down' : 'chevron-forward'} size={16} color={p.accent} />
        <Text style={{ color: p.accent, fontSize: 13.5, fontWeight: '700' }}>
          Texto oficial de ENAIRE
        </Text>
      </Pressable>

      {openOfficial ? (
        <View style={{ marginTop: 8, gap: 8 }}>
          {paragraphs.length > 0 ? (
            paragraphs.map((para, i) => (
              <Text key={i} style={{ color: p.text, fontSize: 13.5, lineHeight: 20 }}>
                {para}
              </Text>
            ))
          ) : (
            <Text style={{ color: p.textMuted, fontSize: 13.5, lineHeight: 20, fontStyle: 'italic' }}>
              ENAIRE no publica un texto descriptivo para esta zona. La información disponible es
              la de los campos estructurados que aparecen arriba.
            </Text>
          )}
        </View>
      ) : null}

      <Pressable
        onPress={() => setOpenDetails((v) => !v)}
        style={{ flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 6, marginTop: 2 }}
        accessibilityRole="button"
      >
        <Ionicons name={openDetails ? 'chevron-down' : 'chevron-forward'} size={16} color={p.textMuted} />
        <Text style={{ color: p.textMuted, fontSize: 13, fontWeight: '600' }}>Datos técnicos</Text>
      </Pressable>

      {openDetails ? (
        <View style={{ marginTop: 4, gap: 3 }}>
          <TechRow label="Identificador" value={zone.identifier} />
          <TechRow label="Tipo (ED-318)" value={zone.type} />
          <TechRow label="Motivos" value={zone.reasons.join(', ') || '—'} />
          <TechRow label="Límites publicados" value={rawBandLabel(zone)} />
          <TechRow label="Capa" value={layerLabel[zone.layer]} />
          {zone.updatedAt ? <TechRow label="Actualizada" value={zone.updatedAt.replace('T', ' ')} /> : null}
        </View>
      ) : null}
    </View>
  );
}

function TechRow({ label, value }: { label: string; value: string }) {
  const p = usePalette();
  return (
    <View style={{ flexDirection: 'row', justifyContent: 'space-between', gap: 12 }}>
      <Text style={{ color: p.textFaint, fontSize: 12 }}>{label}</Text>
      <Text style={{ color: p.textMuted, fontSize: 12, flexShrink: 1, textAlign: 'right' }}>{value}</Text>
    </View>
  );
}
