import React from 'react';
import { ActivityIndicator, Pressable, StyleSheet, Text, View, type ViewStyle } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { usePalette } from '../hooks/useTheme';
import { radius, shadow } from '../theme';

export function Card({
  children,
  style,
  padded = true,
}: {
  children: React.ReactNode;
  style?: ViewStyle | ViewStyle[];
  padded?: boolean;
}) {
  const p = usePalette();
  return (
    <View
      style={[
        {
          backgroundColor: p.card,
          borderRadius: radius.lg,
          borderWidth: StyleSheet.hairlineWidth,
          borderColor: p.cardBorder,
          padding: padded ? 16 : 0,
          overflow: 'hidden',
        },
        shadow,
        style as ViewStyle,
      ]}
    >
      {children}
    </View>
  );
}

export function SectionTitle({ children, right }: { children: React.ReactNode; right?: React.ReactNode }) {
  const p = usePalette();
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
      <Text
        style={{
          color: p.textMuted,
          fontSize: 12,
          fontWeight: '700',
          letterSpacing: 0.9,
          textTransform: 'uppercase',
        }}
      >
        {children}
      </Text>
      {right}
    </View>
  );
}

export function Chip({
  label,
  color,
  icon,
  small,
}: {
  label: string;
  color?: string;
  icon?: keyof typeof Ionicons.glyphMap;
  small?: boolean;
}) {
  const p = usePalette();
  const c = color ?? p.textMuted;
  return (
    <View
      style={{
        flexDirection: 'row',
        alignItems: 'center',
        gap: 4,
        backgroundColor: c + (p.scheme === 'dark' ? '22' : '18'),
        borderRadius: radius.pill,
        paddingHorizontal: small ? 8 : 10,
        paddingVertical: small ? 3 : 5,
      }}
    >
      {icon ? <Ionicons name={icon} size={small ? 11 : 13} color={c} /> : null}
      <Text style={{ color: c, fontSize: small ? 11 : 12, fontWeight: '700' }}>{label}</Text>
    </View>
  );
}

export function PrimaryButton({
  label,
  onPress,
  icon,
  loading,
  disabled,
  color,
  style,
}: {
  label: string;
  onPress: () => void;
  icon?: keyof typeof Ionicons.glyphMap;
  loading?: boolean;
  disabled?: boolean;
  color?: string;
  style?: ViewStyle;
}) {
  const p = usePalette();
  const bg = color ?? p.accent;
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={label}
      onPress={onPress}
      disabled={disabled || loading}
      style={({ pressed }) => [
        {
          backgroundColor: bg,
          opacity: disabled ? 0.45 : pressed ? 0.85 : 1,
          borderRadius: radius.pill,
          paddingVertical: 16,
          paddingHorizontal: 22,
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'center',
          gap: 10,
        },
        shadow,
        style,
      ]}
    >
      {loading ? (
        <ActivityIndicator color="#fff" />
      ) : icon ? (
        <Ionicons name={icon} size={20} color="#fff" />
      ) : null}
      <Text style={{ color: '#fff', fontSize: 16, fontWeight: '700' }}>{label}</Text>
    </Pressable>
  );
}

export function GhostButton({
  label,
  onPress,
  icon,
}: {
  label: string;
  onPress: () => void;
  icon?: keyof typeof Ionicons.glyphMap;
}) {
  const p = usePalette();
  return (
    <Pressable
      accessibilityRole="button"
      onPress={onPress}
      style={({ pressed }) => ({
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 8,
        paddingVertical: 12,
        paddingHorizontal: 16,
        borderRadius: radius.pill,
        borderWidth: StyleSheet.hairlineWidth,
        borderColor: p.cardBorder,
        backgroundColor: pressed ? p.accentSoft : 'transparent',
      })}
    >
      {icon ? <Ionicons name={icon} size={17} color={p.accent} /> : null}
      <Text style={{ color: p.accent, fontWeight: '700', fontSize: 14 }}>{label}</Text>
    </Pressable>
  );
}

export function Divider() {
  const p = usePalette();
  return <View style={{ height: StyleSheet.hairlineWidth, backgroundColor: p.divider, marginVertical: 12 }} />;
}

export function InfoRow({
  label,
  value,
  mono,
}: {
  label: string;
  value: string;
  mono?: boolean;
}) {
  const p = usePalette();
  return (
    <View style={{ flexDirection: 'row', justifyContent: 'space-between', gap: 16, paddingVertical: 4 }}>
      <Text style={{ color: p.textMuted, fontSize: 13, flexShrink: 0 }}>{label}</Text>
      <Text
        style={{
          color: p.text,
          fontSize: 13,
          fontWeight: '600',
          textAlign: 'right',
          flexShrink: 1,
          fontVariant: mono ? ['tabular-nums'] : undefined,
        }}
      >
        {value}
      </Text>
    </View>
  );
}

export function Banner({
  tone = 'info',
  icon,
  children,
}: {
  tone?: 'info' | 'warn';
  icon?: keyof typeof Ionicons.glyphMap;
  children: React.ReactNode;
}) {
  const p = usePalette();
  const color = tone === 'warn' ? '#C77700' : p.textMuted;
  return (
    <View
      style={{
        flexDirection: 'row',
        gap: 10,
        backgroundColor: color + (p.scheme === 'dark' ? '1F' : '14'),
        borderRadius: radius.md,
        padding: 12,
      }}
    >
      <Ionicons name={icon ?? (tone === 'warn' ? 'warning-outline' : 'information-circle-outline')} size={17} color={color} style={{ marginTop: 1 }} />
      <Text style={{ color: p.text, fontSize: 12.5, lineHeight: 18, flex: 1 }}>{children}</Text>
    </View>
  );
}
