import { queryZonesAt } from '../api/enaire';
import { ELEVATION_SOURCE, getTerrainElevation } from '../api/elevation';
import type { Coords, QueryResult } from '../types';
import { buildVerdict, evaluateZones } from './verdict';

/**
 * Consulta completa de un punto: zonas de ENAIRE + elevación del terreno,
 * y a partir de ahí el veredicto. Todo se ejecuta en el móvil.
 */
export async function checkPoint(
  coords: Coords,
  flightHeightAgl: number,
  signal?: AbortSignal,
): Promise<QueryResult> {
  const [zonesResult, terrainElevation] = await Promise.all([
    queryZonesAt(coords.lat, coords.lon, signal),
    getTerrainElevation(coords.lat, coords.lon, signal),
  ]);

  const evaluated = evaluateZones(zonesResult.zones, flightHeightAgl, terrainElevation);
  const verdict = buildVerdict(evaluated, flightHeightAgl);

  return {
    coords,
    terrainElevation,
    terrainSource: terrainElevation === null ? null : ELEVATION_SOURCE,
    flightHeightAgl,
    zones: evaluated,
    verdict,
    queriedAt: new Date().toISOString(),
    failedLayers: zonesResult.failedLayers,
  };
}
