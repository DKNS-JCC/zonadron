import { ENAIRE_SERVICE } from '../api/enaire';
import { LEAFLET_CSS, LEAFLET_JS } from './leafletVendor';

export interface MapOptions {
  lat: number;
  lon: number;
  zoom: number;
  /** ids reales de las capas del servicio de ENAIRE. */
  layerIds: { aero: number; urbano: number; infraestructuras: number };
  /** Capas visibles al abrir el mapa. */
  visible: { aero: boolean; urbano: boolean; infraestructuras: boolean };
  dark: boolean;
}

/**
 * Mapa Leaflet embebido en un WebView.
 *
 * - Base: OpenStreetMap (y CARTO en modo oscuro).
 * - Encima: las capas oficiales de ENAIRE, pedidas al endpoint `export` del
 *   propio servicio ArcGIS. Es decir, el dibujo de las zonas es el que publica
 *   ENAIRE, no una reinterpretación nuestra.
 *
 * Se usa WebView (en vez de react-native-maps) por dos motivos: no necesita
 * ninguna clave de API de Google/Apple y permite superponer exactamente las
 * teselas oficiales de ENAIRE.
 */
export function buildMapHtml(opts: MapOptions): string {
  const { lat, lon, zoom, layerIds, visible, dark } = opts;

  const baseUrl = dark
    ? 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png'
    : 'https://tile.openstreetmap.org/{z}/{x}/{y}.png';
  const baseAttr = dark
    ? '&copy; OpenStreetMap &copy; CARTO'
    : '&copy; OpenStreetMap';

  return `<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<style>${LEAFLET_CSS}</style>
<style>
  html, body, #map { height: 100%; margin: 0; padding: 0; background: ${dark ? '#0B1220' : '#F4F6FA'}; }
  .leaflet-container { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; }
  .leaflet-control-attribution { font-size: 9px; opacity: .8; }
  /* Se aparta la atribución del botón de consulta que flota abajo. */
  .leaflet-bottom.leaflet-right { margin-bottom: 88px; }
  .crosshair {
    position: absolute; left: 50%; top: 50%; transform: translate(-50%,-50%);
    width: 34px; height: 34px; pointer-events: none; z-index: 500;
  }
  .crosshair:before, .crosshair:after {
    content: ''; position: absolute; background: ${dark ? '#F2F5FA' : '#0B1220'};
    box-shadow: 0 0 0 1px ${dark ? '#0B1220AA' : '#FFFFFFAA'};
  }
  .crosshair:before { left: 16px; top: 0; width: 2px; height: 34px; }
  .crosshair:after { top: 16px; left: 0; height: 2px; width: 34px; }
  .hint {
    position: absolute; left: 50%; bottom: 96px; transform: translateX(-50%);
    background: ${dark ? '#141E31EE' : '#FFFFFFEE'}; color: ${dark ? '#F2F5FA' : '#0B1220'};
    padding: 7px 14px; border-radius: 999px; font-size: 12px; z-index: 500;
    border: 1px solid ${dark ? '#243247' : '#E2E7F0'}; pointer-events: none;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    transition: opacity .4s; box-shadow: 0 4px 14px rgba(0,0,0,.18);
  }
</style>
</head>
<body>
<div id="map"></div>
<div class="crosshair" id="crosshair"></div>
<div class="hint" id="hint">Toca el mapa o mueve la cruz para consultar un punto</div>
<script>${LEAFLET_JS}</script>
<script>
(function () {
  // Puente con la app: en móvil vía WebView, en la vista web vía iframe.
  var post = function (obj) {
    var payload = JSON.stringify(obj);
    if (window.ReactNativeWebView) window.ReactNativeWebView.postMessage(payload);
    else if (window.parent && window.parent !== window) window.parent.postMessage(payload, '*');
  };

  // Sin controles de zoom: estorban a la cabecera flotante y en móvil se usa
  // el gesto de pellizcar.
  var map = L.map('map', { zoomControl: false, attributionControl: true })
    .setView([${lat}, ${lon}], ${zoom});

  L.tileLayer('${baseUrl}', {
    maxZoom: 19, attribution: '${baseAttr}'
  }).addTo(map);

  // --- Capas oficiales de ENAIRE (endpoint export del servicio ArcGIS) ---
  // Se usa UNA sola capa que pide las tres a la vez (layers=show:a,b,c). Así se
  // hace una petición por tesela en lugar de tres: el servicio de ENAIRE limita
  // las peticiones simultáneas y con tres capas separadas devolvía teselas vacías.
  var LAYER_IDS = ${JSON.stringify(layerIds)};
  var visibleKeys = ${JSON.stringify(visible)};

  function activeIds() {
    return Object.keys(LAYER_IDS)
      .filter(function (k) { return visibleKeys[k]; })
      .map(function (k) { return LAYER_IDS[k]; });
  }

  var EnaireLayer = L.TileLayer.extend({
    getTileUrl: function (coords) {
      var size = this.getTileSize();
      var nwPoint = coords.scaleBy(size);
      var sePoint = nwPoint.add(size);
      var nw = map.options.crs.project(map.unproject(nwPoint, coords.z));
      var se = map.options.crs.project(map.unproject(sePoint, coords.z));
      var bbox = [nw.x, se.y, se.x, nw.y].join(',');
      return '${ENAIRE_SERVICE}/export?bbox=' + bbox +
        '&bboxSR=3857&imageSR=3857&size=256,256&dpi=96&format=png32&transparent=true' +
        '&layers=show:' + activeIds().join(',') + '&f=image';
    }
  });

  var enaire = new EnaireLayer('', {
    opacity: 0.55,
    maxZoom: 19,
    attribution: 'Zonas UAS &copy; ENAIRE',
    updateWhenIdle: true,
    keepBuffer: 1
  });
  if (activeIds().length) enaire.addTo(map);

  function applyVisibility(next) {
    visibleKeys = next;
    if (activeIds().length === 0) {
      if (map.hasLayer(enaire)) map.removeLayer(enaire);
      return;
    }
    if (!map.hasLayer(enaire)) enaire.addTo(map);
    enaire.redraw();
  }

  var marker = null;
  var accuracyCircle = null;

  function setMarker(lat, lon) {
    if (marker) map.removeLayer(marker);
    marker = L.circleMarker([lat, lon], {
      radius: 8, color: '#FFFFFF', weight: 3,
      fillColor: '#1D63FF', fillOpacity: 1
    }).addTo(map);
  }

  var hint = document.getElementById('hint');
  var hideHint = setTimeout(function () { hint.style.opacity = '0'; }, 4500);

  map.on('click', function (e) {
    clearTimeout(hideHint); hint.style.opacity = '0';
    setMarker(e.latlng.lat, e.latlng.lng);
    post({ type: 'pick', lat: e.latlng.lat, lon: e.latlng.lng, zoom: map.getZoom() });
  });

  map.on('moveend', function () {
    var c = map.getCenter();
    post({ type: 'move', lat: c.lat, lon: c.lng, zoom: map.getZoom() });
  });

  // --- Mensajes desde React Native ---
  function handleMessage(raw) {
    var msg;
    try { msg = JSON.parse(raw); } catch (err) { return; }
    if (msg.type === 'center') {
      map.setView([msg.lat, msg.lon], msg.zoom || map.getZoom(), { animate: true });
      if (msg.marker !== false) setMarker(msg.lat, msg.lon);
    } else if (msg.type === 'marker') {
      setMarker(msg.lat, msg.lon);
    } else if (msg.type === 'accuracy') {
      if (accuracyCircle) map.removeLayer(accuracyCircle);
      accuracyCircle = L.circle([msg.lat, msg.lon], {
        radius: msg.radius, color: '#1D63FF', weight: 1, fillOpacity: 0.08
      }).addTo(map);
    } else if (msg.type === 'layers') {
      applyVisibility(msg.visible);
    } else if (msg.type === 'pickCenter') {
      var c = map.getCenter();
      setMarker(c.lat, c.lng);
      post({ type: 'pick', lat: c.lat, lon: c.lng, zoom: map.getZoom() });
    }
  }

  document.addEventListener('message', function (e) { handleMessage(e.data); });
  window.addEventListener('message', function (e) { handleMessage(e.data); });

  post({ type: 'ready' });
})();
</script>
</body>
</html>`;
}
