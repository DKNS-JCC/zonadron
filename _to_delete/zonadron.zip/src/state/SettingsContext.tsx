import AsyncStorage from '@react-native-async-storage/async-storage';
import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';

const KEY = 'zonadron.settings.v1';

/**
 * Altura de vuelo prevista, en metros sobre el terreno (AGL).
 * 120 m es el límite general de la categoría abierta en el Reglamento (UE)
 * 2019/947, así que es el valor por defecto más razonable.
 */
export const DEFAULT_HEIGHT = 120;

export const HEIGHT_PRESETS = [30, 60, 120] as const;

interface Settings {
  flightHeight: number;
  showNotAffecting: boolean;
}

interface SettingsContextValue extends Settings {
  ready: boolean;
  setFlightHeight: (h: number) => void;
  setShowNotAffecting: (v: boolean) => void;
}

const defaults: Settings = { flightHeight: DEFAULT_HEIGHT, showNotAffecting: false };

const Ctx = createContext<SettingsContextValue>({
  ...defaults,
  ready: false,
  setFlightHeight: () => {},
  setShowNotAffecting: () => {},
});

export function SettingsProvider({ children }: { children: React.ReactNode }) {
  const [settings, setSettings] = useState<Settings>(defaults);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let alive = true;
    AsyncStorage.getItem(KEY)
      .then((raw) => {
        if (!alive) return;
        if (raw) {
          try {
            const parsed = JSON.parse(raw);
            setSettings({
              flightHeight:
                Number.isFinite(parsed?.flightHeight) && parsed.flightHeight > 0
                  ? Math.min(900, Number(parsed.flightHeight))
                  : DEFAULT_HEIGHT,
              showNotAffecting: Boolean(parsed?.showNotAffecting),
            });
          } catch {
            /* valores por defecto */
          }
        }
      })
      .finally(() => alive && setReady(true));
    return () => {
      alive = false;
    };
  }, []);

  const persist = useCallback((next: Settings) => {
    setSettings(next);
    AsyncStorage.setItem(KEY, JSON.stringify(next)).catch(() => {});
  }, []);

  const value = useMemo<SettingsContextValue>(
    () => ({
      ...settings,
      ready,
      setFlightHeight: (h) => persist({ ...settings, flightHeight: Math.max(1, Math.min(900, Math.round(h))) }),
      setShowNotAffecting: (v) => persist({ ...settings, showNotAffecting: v }),
    }),
    [settings, ready, persist],
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useSettings() {
  return useContext(Ctx);
}
