import { Platform } from 'react-native';
import type { VerdictLevel } from './types';

export interface Palette {
  bg: string;
  bgElevated: string;
  card: string;
  cardBorder: string;
  text: string;
  textMuted: string;
  textFaint: string;
  accent: string;
  accentSoft: string;
  divider: string;
  tabBar: string;
  overlay: string;
  scheme: 'light' | 'dark';
}

export const lightPalette: Palette = {
  scheme: 'light',
  bg: '#F4F6FA',
  bgElevated: '#FFFFFF',
  card: '#FFFFFF',
  cardBorder: '#E2E7F0',
  text: '#0B1220',
  textMuted: '#5A6577',
  textFaint: '#8B95A7',
  accent: '#1D63FF',
  accentSoft: '#E8EFFF',
  divider: '#EAEEF5',
  tabBar: '#FFFFFFEE',
  overlay: '#0B122055',
};

export const darkPalette: Palette = {
  scheme: 'dark',
  bg: '#0B1220',
  bgElevated: '#131C2E',
  card: '#141E31',
  cardBorder: '#243247',
  text: '#F2F5FA',
  textMuted: '#9AA7BC',
  textFaint: '#6C7A91',
  accent: '#5C93FF',
  accentSoft: '#1B2942',
  divider: '#1E2A3D',
  tabBar: '#0F1828EE',
  overlay: '#00000088',
};

export interface VerdictStyle {
  /** Color principal, usado sobre fondos claros y oscuros. */
  color: string;
  /** Fondo suave para tarjetas. */
  soft: string;
  softDark: string;
  icon: string;
  label: string;
}

export const verdictStyles: Record<VerdictLevel, VerdictStyle> = {
  LIBRE: {
    color: '#0E9F6E',
    soft: '#E4F7EF',
    softDark: '#0C2A20',
    icon: 'checkmark-circle',
    label: 'Sin restricciones específicas',
  },
  CONDICIONES: {
    color: '#C77700',
    soft: '#FFF4E0',
    softDark: '#2E2208',
    icon: 'alert-circle',
    label: 'Puedes volar, con condiciones',
  },
  AUTORIZACION: {
    color: '#E05A00',
    soft: '#FFEDE0',
    softDark: '#331B08',
    icon: 'shield-half',
    label: 'Necesitas autorización',
  },
  PROHIBIDO: {
    color: '#D92D20',
    soft: '#FDE8E6',
    softDark: '#33110F',
    icon: 'close-circle',
    label: 'No puedes volar',
  },
  DESCONOCIDO: {
    color: '#6C7A91',
    soft: '#EDF0F5',
    softDark: '#1B2434',
    icon: 'help-circle',
    label: 'No se ha podido comprobar',
  },
};

export function verdictBg(level: VerdictLevel, palette: Palette): string {
  const s = verdictStyles[level];
  return palette.scheme === 'dark' ? s.softDark : s.soft;
}

export const radius = { sm: 10, md: 16, lg: 22, pill: 999 };

export const spacing = (n: number) => n * 4;

export const shadow = Platform.select({
  ios: {
    shadowColor: '#0B1220',
    shadowOpacity: 0.08,
    shadowRadius: 16,
    shadowOffset: { width: 0, height: 6 },
  },
  android: { elevation: 3 },
  default: {},
}) as object;

export const font = {
  mono: Platform.select({ ios: 'Menlo', android: 'monospace', default: 'monospace' }) as string,
};
